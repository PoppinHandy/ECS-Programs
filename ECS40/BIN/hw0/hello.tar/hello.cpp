#include <iostream>

int main(){
	std::cout << "Hello ECS40 from 42129\n";
	return 0;
}//end main
